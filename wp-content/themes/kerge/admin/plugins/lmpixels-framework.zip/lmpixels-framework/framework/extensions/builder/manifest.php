<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['name'] = __( 'Builder', 'fw' );
$manifest['version'] = '1.0.0';
$manifest['author'] = 'LMPixels';
$manifest['author_uri'] = 'https://themeforest.net/user/lmpixels';
$manifest['requirements'] = array(
	'framework' => array(
		'min_version' => '1.0.0',
	),
);
