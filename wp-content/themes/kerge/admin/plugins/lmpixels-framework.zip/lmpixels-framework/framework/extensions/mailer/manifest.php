<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['name'] = __('Mailer', 'fw');
$manifest['description'] = __('This extension will let you set some global email options and it is used by other extensions (like Forms) to send emails.', 'fw');
$manifest['version'] = '1.2.12';
$manifest['standalone'] = false;
$manifest['display'] = false;
$manifest['version'] = '1.0.0';
$manifest['author'] = 'LMPixels';
$manifest['author_uri'] = 'https://themeforest.net/user/lmpixels';
