<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'table'         => array(
		'type'  => 'table',
		'label' => false,
		'desc'  => false,
	)
);