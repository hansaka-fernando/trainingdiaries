<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Info List', 'leven-shortcodes' ),
	'description' => esc_html__( 'Add some Information', 'leven-shortcodes' ),
	'tab'         => esc_html__( 'Leven Elements', 'leven-shortcodes' ),
);